function tabuada() {
  let num = document.getElementById("num").value;

  for (let i = 1; i <= 10; i++) {
    alert(num + " x " + i + " = " + (num * i));
  }
}
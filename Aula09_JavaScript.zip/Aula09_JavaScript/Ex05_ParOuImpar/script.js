function somar() {
  let n1 = parseInt(document.getElementById("n1").value);
  let n2 = parseInt(document.getElementById("n2").value);
  let resultado = n1 + n2;

  let btn = document.getElementById("btn");

  if (resultado % 2 === 0) {
    btn.style.backgroundColor = "blue";
  } else {
    btn.style.backgroundColor = "green";
  }

  alert(resultado);
}